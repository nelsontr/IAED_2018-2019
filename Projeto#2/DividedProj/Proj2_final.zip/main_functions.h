#ifndef MAIN_FUNCTIONS_H
#define MAIN_FUNCTIONS_H

/*_______________/----- PROTOTYPES -----\_______________*/
void command_a(char name[], char email[], char phone[]);
void command_p(char name[]);
void command_r(char name[]);
void command_e(char name[],char email[]);
void command_c(char email[]);
void command_x();

#endif
